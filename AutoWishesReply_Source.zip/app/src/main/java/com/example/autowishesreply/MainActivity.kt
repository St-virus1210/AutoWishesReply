package com.example.autowishesreply

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
 private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,32,28,28) }
  root.addView(TextView(this).apply { text="Auto Wishes Reply"; textSize=27f; gravity=Gravity.CENTER_VERTICAL })
  root.addView(TextView(this).apply { text="WhatsApp • Personal use • Hindi + English"; textSize=14f; setPadding(0,8,0,22) })
  root.addView(CheckBox(this).apply {
   text="Automatic replies ON"; textSize=17f; isChecked=prefs.getBoolean("enabled",false)
   setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("enabled",v).apply() }
  })
  root.addView(section("Reply categories"))
  addToggle(root,"Birthday wishes","birthday_enabled")
  addToggle(root,"Festival wishes","festival_enabled")
  addToggle(root,"Congratulations","congrats_enabled")
  root.addView(section("Reply language"))
  val spinner=Spinner(this)
  spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("Auto-detect Hindi / English","Hindi replies","English replies"))
  spinner.setSelection(prefs.getInt("language",0))
  spinner.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener {
   override fun onItemSelected(p:android.widget.AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){prefs.edit().putInt("language",pos).apply()}
   override fun onNothingSelected(p:android.widget.AdapterView<*>?){}
  }
  root.addView(spinner)
  root.addView(section("Recipients"))
  root.addView(TextView(this).apply { text="All WhatsApp chats with a supported inline Reply action."; textSize=14f })
  root.addView(Button(this).apply { text="Open notification access settings"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } })
  root.addView(Button(this).apply { text="View reply history"; setOnClickListener { showHistory() } })
  root.addView(TextView(this).apply {
   text="Automatic sending is possible only when WhatsApp exposes an inline reply action in its notification. It may not work for every chat, grouped notification, media-only wish or device version. Keep notification previews enabled."
   textSize=12f; setPadding(0,18,0,0)
  })
  root.addView(TextView(this).apply { text="Privacy: message processing stays on this phone; no message content is uploaded."; textSize=12f; setPadding(0,12,0,0) })
  setContentView(ScrollView(this).apply { addView(root) })
 }
 private fun section(s:String)=TextView(this).apply { text=s; textSize=18f; setPadding(0,22,0,8) }
 private fun addToggle(root:LinearLayout,label:String,key:String) {
  root.addView(CheckBox(this).apply { text=label; isChecked=prefs.getBoolean(key,true); setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean(key,v).apply() } })
 }
 private fun showHistory() {
  val value=prefs.getString("history","").orEmpty()
  android.app.AlertDialog.Builder(this).setTitle("Recent automatic replies")
   .setMessage(if(value.isBlank()) "No replies recorded yet." else value)
   .setPositiveButton("OK",null).setNeutralButton("Clear history") { _,_ -> prefs.edit().putString("history","").apply() }.show()
 }
}
