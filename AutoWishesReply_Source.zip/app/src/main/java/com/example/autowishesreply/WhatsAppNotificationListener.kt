package com.example.autowishesreply

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.security.MessageDigest

class WhatsAppNotificationListener : NotificationListenerService() {
 override fun onNotificationPosted(sbn:StatusBarNotification) {
  if(sbn.packageName!="com.whatsapp" && sbn.packageName!="com.whatsapp.w4b") return
  val prefs=getSharedPreferences("settings",MODE_PRIVATE)
  if(!prefs.getBoolean("enabled",false)) return
  val n=sbn.notification ?: return
  val ex=n.extras ?: return
  val sender=ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
  val msg=(ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()+" "+ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()).trim()
  if(msg.isBlank()) return
  val category=classify(msg) ?: return
  val active=when(category) {
   "birthday" -> prefs.getBoolean("birthday_enabled",true)
   "festival" -> prefs.getBoolean("festival_enabled",true)
   else -> prefs.getBoolean("congrats_enabled",true)
  }
  if(!active) return
  val fingerprint=hash("${sbn.key}|$sender|$msg")
  val seen=prefs.getStringSet("seen",emptySet())?.toMutableSet() ?: mutableSetOf()
  if(fingerprint in seen) return
  val reply=makeReply(category,msg,prefs.getInt("language",0))
  val action=n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput }==true } ?: return
  val input=action.remoteInputs?.firstOrNull { it.allowFreeFormInput } ?: return
  try {
   val intent=Intent()
   val bundle=android.os.Bundle().apply { putCharSequence(input.resultKey,reply) }
   RemoteInput.addResultsToIntent(arrayOf(input),intent,bundle)
   action.actionIntent.send(this,0,intent)
   seen.add(fingerprint)
   while(seen.size>150) seen.remove(seen.first())
   prefs.edit().putStringSet("seen",seen).apply()
   val old=prefs.getString("history","").orEmpty()
   val entry="• ${category.replaceFirstChar { it.uppercase() }} | ${sender.take(40)}\n  $reply"
   prefs.edit().putString("history",(listOf(entry)+old.lines().filter{it.isNotBlank()}).take(30).joinToString("\n")).apply()
  } catch(e:Exception) { Log.w("AutoWishesReply","Inline reply failed; delivery not confirmed",e) }
 }
 private fun classify(raw:String):String? {
  val s=raw.lowercase()
  val b=listOf("happy birthday","hbd","many many happy returns","जन्मदिन","जन्म दिवस","जन्मदिन की")
  val f=listOf("happy diwali","happy holi","happy new year","merry christmas","दीपावली","दिवाली","होली","नववर्ष","नया साल","ईद मुबारक","क्रिसमस")
  val c=listOf("congratulations","congrats","well done","many congratulations","शुभकामनाएं","शुभकामनाएँ","बधाई","बहुत बहुत बधाई","हार्दिक बधाई")
  return when { b.any{s.contains(it)}->"birthday"; f.any{s.contains(it)}->"festival"; c.any{s.contains(it)}->"congrats"; else->null }
 }
 private fun makeReply(category:String,msg:String,mode:Int):String {
  val hindi=when(mode){1->true;2->false;else->msg.any{it in '\u0900'..'\u097F'}}
  return when(category) {
   "birthday" -> if(hindi) "आपकी प्यारी शुभकामनाओं और आशीर्वाद के लिए बहुत-बहुत धन्यवाद। 🙏" else "Thank you so much for your lovely birthday wishes and blessings. 🙏"
   "festival" -> if(hindi) "आपको और आपके परिवार को भी हार्दिक शुभकामनाएँ। 🙏" else "Thank you! Wishing you and your family happiness and prosperity too. 🙏"
   else -> if(hindi) "आपकी शुभकामनाओं और प्रोत्साहन के लिए दिल से धन्यवाद। 🙏" else "Thank you so much for your wishes and encouragement. 🙏"
  }
 }
 private fun hash(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
}
