# AutoWishesReply — Android source project (v0.3)

Personal-use Android app for automatic preset replies to eligible WhatsApp and WhatsApp Business notifications.

## Features
- WhatsApp Messenger and WhatsApp Business package detection.
- Birthday, festival and congratulations categories with independent switches.
- Hindi, English or automatic language selection.
- Preset replies; no external AI service or server.
- Duplicate-notification suppression and local reply history.
- Android notification inline-reply integration.

## Build
This is source code, not an installable APK. Build a debug APK with JDK 17, Android SDK platform 35/build tools 35.0.0 and Gradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Install and setup
1. Install `app-debug.apk` on your Android phone.
2. Open Auto Wishes Reply.
3. Tap **Open notification access settings** and enable Auto Wishes Reply.
4. Return to the app and switch **Automatic replies ON**.
5. Keep WhatsApp notification previews enabled and test with a trusted contact first.

## Important limitations and privacy
- Android/WhatsApp only exposes inline reply actions for some notifications. Replies cannot be guaranteed for every chat, group, media-only message, sticker, voice note, hidden preview or device/OS version.
- Sending an inline-reply action is not proof of delivery or read status.
- “All chats” means chats whose notifications expose a compatible inline-reply action.
- Notification access is powerful. Install only a build you trust and grant this app notification access only if you accept that it can read notification content locally.
- Message processing and reply history stay on the device; this project contains no message-upload server or AI API.
- The debug APK is for personal testing, not a Play Store release.
